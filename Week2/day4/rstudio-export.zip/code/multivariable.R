library(timereg)
data(melanoma)
