# Scatter plot
plot(price ~ weight, data=cars, xlab="Weight (Pounds)", ylab="Price ($1000s)")