display_swirl_file("customTests.R","Writing_swirl_Courses", "Other_Question_Types")

# Display a box plot for use in the range question 
boxplot(galton, ylab="Height in inches", main="Box Plot of Galton Data")
abline(h=68, col="red", lty=2)
abline(h=69, col="red", lty=2)
