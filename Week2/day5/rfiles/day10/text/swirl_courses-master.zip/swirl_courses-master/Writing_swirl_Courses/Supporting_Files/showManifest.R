display_swirl_file("MANIFEST", "Writing swirl Courses")
