# This file attempts to display the Introduction's lesson.yaml file.
display_swirl_file("lesson.yaml", "Writing swirl Courses", "Lesson Files")
