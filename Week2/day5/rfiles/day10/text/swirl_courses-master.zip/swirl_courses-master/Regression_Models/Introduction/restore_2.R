plot(jitter(child,4) ~ parent,galton)
