
The source files are processed using knitr, an R package that makes Sweave easier in RStudio. If you are unfamiliar with RStudio or Sweave, you may consider creating your own copy of the Google Doc version of each lab.

For information about knitr, please visit

http://yihui.name/knitr/
